#include <stdio.h> 
#include <stdlib.h>
int main(){
    int n , i, *ptr, sum= 0 ; 
    printf ("Enter the size of the array"); 
    scanf ("%d", &n); 

    ptr = (int*)malloc (n*sizeof(int));
    //to check for memory allocation 

    if (ptr == NULL){
        printf ("error allocating memory"); 
    } 
    for (int i = 0 ; i < n ; i++)
    {
        printf ("enter %d element",i+1); 
        scanf ("%d", (ptr+i)); 
        sum += *(ptr+i);
    }
    int *fpt; 
    int n2; 
    printf ("update the size of the array\n"); 
    scanf ("%d", &n2);
    fpt = realloc(ptr,n2*sizeof(int)); 
    
    for (int i = n ; i < n2 ; i++ ){
        printf ("enter %d element",i+1); 
        scanf ("%d", (ptr+i)); 
        sum += *(ptr+i) ;
    }
    printf ("the sum is : %d", sum);
    free(fpt);
    free(ptr); 
    return 0 ; 
}